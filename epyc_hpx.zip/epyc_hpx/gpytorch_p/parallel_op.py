import time
import logging
import torch
import gpytorch
import os

import numpy as np
from config import get_config
from gpytorch_logger import setup_logging
from utils import load_data
from sklearn.metrics.pairwise import rbf_kernel
from scipy.linalg import cholesky, solve_triangular

logger = logging.getLogger()
log_filename = "./op_paralll_gpytorch.log"


def rbf_kernel(X, gamma):
    # Compute pairwise squared Euclidean distances
    sq_dists = torch.cdist(X, X, p=2).pow(2)
    # Compute RBF kernel
    K = torch.exp(-gamma * sq_dists)
    return K

def gpytorch_run(config, output_file, size_train, l, cores):
    """
    Run the Gaussian process regression pipeline.

    Args:
        config (dict): Configuration parameters for the pipeline.
        output_csv_obj (csv.writer): CSV writer object for writing output data.
        size_train (int): Size of the training dataset.
        l (int): Loop index.
    """
    X_train, Y_train, X_test = load_data(
        train_in_path=config["train_in_file"],
        train_out_path=config["train_out_file"],
        test_in_path=config["test_in_file"],
        size_train=size_train,
        size_test=config["N_TEST"],
        n_regressors=config["N_REG"],
    )

    #X_train = torch.tensor(X_train, dtype=torch.float64)

    #chol_t = time.time()
    K = rbf_kernel(X_train, gamma=1./(2*(1.**2))) + (0.1)*np.eye(X_train.shape[0])
    #cross_K = rbf_kernel(X_train, X_test, gamma=1./(2*(1.**2)))

    # Define gamma for the RBF kernel
    #gamma = 1.0 / (2 * (1.0 ** 2))
    # Compute the RBF kernel matrix
    #K = rbf_kernel(X_train, gamma)
    # Add a small value to the diagonal for numerical stability
    #K += 0.1 * torch.eye(X_train.shape[0])
    #tensor = torch.tensor(K)
    #cross_tensor = torch.tensor(cross_K)

    #L = cholesky(K, lower=True)
    chol_t = time.time()
    #x = solve_triangular(L, K, lower=True)
    X = torch.add(K,K)
    #chol_t = time.time()
    #L = torch.linalg.cholesky(K)
    #Y_train = Y_train.view(-1, 1)
    #X = torch.linalg.solve_triangular(L, Y_train, upper=False)
    #X = torch.linalg.solve_triangular(L.T, X, upper=True)
    #Y = torch.linalg.solve_triangular(L, cross_tensor, upper=False)
    chol_t = time.time() - chol_t

    PRED_UNCER_TIME = chol_t

    logger.info(f"{cores},{size_train},{PRED_UNCER_TIME},{l}")

def execute():
    setup_logging(log_filename, True, logger)
    config = get_config()

    file_path = "./results.txt"
    file_exists = os.path.isfile(file_path)

    with open(file_path, "a") as output_file:
        if not file_exists or os.stat(file_path).st_size == 0:
            # logger.info("Write output file header")
            logger.info("Cores,N_train,N_test,N_reg,Opt_iter,Total_time,Init_time,Opt_Time,Pred_Var_time,Pred_time,N_loop")

        start = config["START"]
        end = config["END"]
        step = config["STEP"]
        torch.set_default_dtype(torch.float64)

        for core in range(0, config["N_CORES"]):
            num_threads = 2**core
            torch.set_num_interop_threads(num_threads)
            torch.set_num_threads(num_threads)
            for data in range(start, end+step, step):
                for l in range(config["LOOP"]):
                    gpytorch_run(config, output_file, data, l, 2**core)


if __name__ == "__main__":
    execute()

