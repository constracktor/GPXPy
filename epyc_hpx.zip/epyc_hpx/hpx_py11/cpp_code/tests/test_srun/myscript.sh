#!/bin/bash	 
#SBATCH --job-name=hpx_fft_job          # Job name
#SBATCH --exclusive                     # Exclusive ressource access
#SBATCH --nodes=1                       # Number of nodes
#SBATCH --ntasks=1                      # Number of MPI ranks
#SBATCH --mem=100	# 100 MB Hauptspeicher
#SBATCH --time=0:05:00	# max. Laufzeit 5 min
#SBATCH --output=slurm.%j.out	# Datei für stdout
#SBATCH --error=slurm.%j.err	# Datei für stderr
# (%N: Nodename, %j: Job-Nr.)
#SBATCH --mail-type=END	# Benachrichtigung bei Ende
#SBATCH --mail-type=FAIL	# Benachrichtigung bei Fehler
#SBATCH --mail-user=st155695@stud.uni-stuttgart.de	# EMail Adresse
# optional
#SBATCH --partition=buran               # Name of partition
#SBATCH --cpus-per-task=32              # Number of cores per MPI rank 
echo "Hello from `hostname`"	# Programm ausfuehren
