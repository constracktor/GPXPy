#!/bin/bash
#SBATCH --job-name=hpx_gpppy_job          		# Job name
#SBATCH --output=hpx_gpppy_job.log        		# Standard output and error log
#SBATCH --mail-type=FAIL                		# Mail events (NONE, BEGIN, END, FAIL, ALL)
#SBATCH --mail-type=END
#SBATCH --mail-user=st155695@stud.uni-stuttgart.de      # Where to send mail	
#SBATCH --time=10:00:00                 		# Time limit hrs:min:sec
#SBATCH --exclusive                     		# Exclusive ressource access
#SBATCH --nodes=1                       		# Number of nodes
#SBATCH --ntasks=1                      		# Number of MPI ranks
# optional
#SBATCH --partition=buran               		# Name of partition
#SBATCH --cpus-per-task=32              		# Number of cores per MPI rank 

# Benchmark script for shared memory strong scaling
# $1: Executable name
# $2: FFTW planning flag (estimate/measure)
# $4: Number of runs
# Parameters
LOOP=2
OPT_ITER=2
N_TILES=10
POW_START=1
POW_STOP=2
#BASE_SIZE=1000
# Get run command
COMMAND="srun -N 1 -n 1 -c 2"
EXECUTABLE="/hpx_gpppy_c" #/$1"
#ARGUMENTS="$LOOP $OPT_ITER $N_TILES"
# Log Info
pwd; hostname; date
# Create directories to store data
#mkdir result
# Strong scaling loop from 2^pow_start to 2^pow_stop cores
#$COMMAND $EXECUTABLE $ARGUMENTS --header=true 

$COMMAND $EXECUTABLE

#for (( j=1; j<$LOOP; j=j+1 ))
#do
#    ARGUMENTS="$j $LOOP $OPT_ITER $N_TILES"
#    $COMMAND $EXECUTABLE $ARGUMENTS
#done
#for (( i=2**$POW_START; i<=2**$POW_STOP; i=i*2 ))
#do
#    ARGUMENTS="$i $LOOP $OPT_ITER $N_TILES"
#    COMMAND="srun -N 1 -n 1 -c $i"
#    for (( j=0; j<$LOOP; j=j+1 ))
#    do
#        $COMMAND $EXECUTABLE $ARGUMENTS
#    done
#done
# Log Info
date
