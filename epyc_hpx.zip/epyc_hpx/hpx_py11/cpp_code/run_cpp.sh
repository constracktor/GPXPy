#!/bin/bash
################################################################################
# Diagnostics
################################################################################
set +x

################################################################################
# Variables
################################################################################
# export APEX_SCREEN_OUTPUT=1 
#export APEX_CSV_OUTPUT=1
#export APEX_DISABLE=1
export CMAKE_COMMAND=cmake
###
export HPX_DIR=/home/helmanmm/epyc_hpx/spack/opt/spack/linux-ubuntu20.04-zen2/gcc-9.4.0/hpx-1.9.1-v4ddbonnaswcns7uxl6sgzuldx7xxayg/lib
export MKL_DIR=/home/helmanmm/epyc_hpx/mkl/epyc_hpx/install/mkl/2024.1/lib

export MKL_CONFIG='-DMKL_ARCH=intel64 -DMKL_LINK=dynamic -DMKL_INTERFACE_FULL=intel_lp64 -DMKL_THREADING=sequential'
################################################################################
# Compile code
################################################################################
rm -rf build && mkdir build && cd build 
$CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release \
		  -DCMAKE_PREFIX_PATH="${HPX_DIR}/cmake/HPX" \
	          -DMKL_DIR="${MKL_DIR}/cmake/mkl" ${MKL_CONFIG} \
	    	  -DHPX_WITH_DYNAMIC_HPX_MAIN=ON \
	  	  -DCMAKE_CXX_FLAGS_RELEASE="-march=native -O3"
make all
make install
################################################################################
# Run benchmark script
################################################################################
cd ..


