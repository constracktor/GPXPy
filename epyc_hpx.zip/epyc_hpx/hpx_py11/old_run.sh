#!/bin/bash
################################################################################
set -e  # Exit immediately if a command exits with a non-zero status.
set -x  # Print each command before executing it.

################################################################################
# Ensure CMAKE_COMMAND is set
################################################################################
export CMAKE_COMMAND=$(which cmake)

if [ -z "$CMAKE_COMMAND" ]; then
  echo "Error: CMAKE_COMMAND environment variable is not set."
  exit 1
fi

export HPX_DIR=/home/helmanmm/spack/opt/spack/linux-ubuntu20.04-cascadelake/gcc-9.4.0/hpx-1.9.1-b7rvujknqv7f63tma3kgucblbgl5y464/lib
export MKL_DIR=/home/helmanmm/mkl/install/mkl/2024.1/lib

export MKL_CONFIG='-DMKL_ARCH=intel64 -DMKL_LINK=dynamic -DMKL_INTERFACE_FULL=intel_lp64 -DMKL_THREADING=sequential'

# Verify and preload necessary MKL libraries
#MKL_LIBS=(
#  "libmkl_core.so"
#  "libmkl_sequential.so"
#  "libmkl_intel_lp64.so"
#)

# Construct LD_PRELOAD
#LD_PRELOAD=""
#for lib in "${MKL_LIBS[@]}"; do
#  if [ -f "${MKL_DIR}/${lib}" ]; then
#    LD_PRELOAD="${LD_PRELOAD}:${MKL_DIR}/${lib}"
#  else
#    echo "Warning: ${MKL_DIR}/${lib} not found."
#  fi
#done
#export LD_PRELOAD

# export LD_PRELOAD="${MKL_DIR}/libmkl_core.so:${MKL_DIR}/libmkl_sequential.so:${MKL_DIR}/libmkl_intel_lp64.so"
#export LD_PRELOAD="${MKL_DIR}/libmkl_core.so:${MKL_DIR}/libmkl_sequential.so:${MKL_DIR}/libmkl_intel_lp64.so:${MKL_DIR}/libmkl_def.so:${MKL_DIR}/libmkl_avx2.so"

# Set LD_LIBRARY_PATH to include MKL_DIR
#export LD_LIBRARY_PATH="${MKL_DIR}:${LD_LIBRARY_PATH}"
#export LD_LIBRARY_PATH=$MKLROOT/lib:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH="${MKL_DIR}"

export LD_PRELOAD="${MKL_DIR}/libmkl_core.so:${MKL_DIR}/libmkl_sequential.so:${MKL_DIR}/libmkl_intel_lp64.so"
export LD_LIBRARY_PATH=$MKLROOT/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH="${MKL_DIR}:${HPX_DIR}:$LD_LIBRARY_PATH"

#export MKL_LINKER_FLAGS="-L${MKL_DIR} -Wl,--no-as-needed"
export MKL_LINKER_FLAGS="-L${MKL_DIR} -Wl,--no-as-needed -lmkl_rt -lpthread -lm -ldl"
################################################################################
# Compile code
################################################################################
rm -rf build && mkdir build && cd build
# $CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release -DPYTHON_LIBRARY_DIR="/usr/local/lib/python3.10/dist-packages" -DPYTHON_EXECUTABLE="/usr/bin/python3" -Dpybind11_DIR="/home/maksim/.local/lib/python3.10/site-packages/pybind11/share/cmake/pybind11" # Configure the project

#$CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release -DPYTHON_LIBRARY_DIR="/usr/local/lib/python3.10/dist-packages" -DPYTHON_EXECUTABLE="/usr/bin/python3" -DCMAKE_PREFIX_PATH="${HPX_DIR}/cmake/HPX" -DHPX_WITH_DYNAMIC_HPX_MAIN=ON -DMKL_DIR="${MKL_DIR}/cmake/mkl" ${MKL_CONFIG} # Configure the project

$CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release \
		  -DPYTHON_LIBRARY_DIR="/usr/local/lib/python3.10/dist-packages" \
		  -DPYTHON_EXECUTABLE="/usr/bin/python3" \
                  -DCMAKE_PREFIX_PATH="${HPX_DIR}/cmake/HPX" \
                  -DHPX_WITH_DYNAMIC_HPX_MAIN=ON \
                  -DMKL_DIR="${MKL_DIR}/cmake/mkl" ${MKL_CONFIG} \
                  -DCMAKE_EXE_LINKER_FLAGS="${MKL_LINKER_FLAGS}"

make -j4 all           # Build the project

#cd ../test
#python3 test_py.py
