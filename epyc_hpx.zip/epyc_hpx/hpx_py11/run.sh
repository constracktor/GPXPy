#!/bin/bash
################################################################################
set -e  # Exit immediately if a command exits with a non-zero status.
set -x  # Print each command before executing it.

################################################################################
# Ensure CMAKE_COMMAND is set
################################################################################
export CMAKE_COMMAND=$(which cmake)

if [ -z "$CMAKE_COMMAND" ]; then
  echo "Error: CMAKE_COMMAND environment variable is not set."
  exit 1
fi

# export APEX_SCREEN_OUTPUT=1
export APEX_DISABLE=1
export HPX_DIR=/home/helmanmm/epyc_hpx/spack/opt/spack/linux-ubuntu20.04-zen2/gcc-9.4.0/hpx-1.9.1-v4ddbonnaswcns7uxl6sgzuldx7xxayg/lib
export MKL_DIR=/home/helmanmm/epyc_hpx/mkl/epyc_hpx/install/mkl/2024.1/lib

export MKL_CONFIG='-DMKL_ARCH=intel64 -DMKL_LINK=dynamic -DMKL_INTERFACE_FULL=intel_lp64 -DMKL_THREADING=sequential'
export LD_LIBRARY_PATH=${MKL_DIR}:${LD_LIBRARY_PATH}

################################################################################
# Compile code
################################################################################
rm -rf build && mkdir build && cd build
# $CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release -DPYTHON_LIBRARY_DIR="/usr/local/lib/python3.10/dist-packages" -DPYTHON_EXECUTABLE="/usr/bin/python3" -Dpybind11_DIR="/home/maksim/.local/lib/python3.10/site-packages/pybind11/share/cmake/pybind11" # Configure the project

$CMAKE_COMMAND .. -DCMAKE_BUILD_TYPE=Release \
       	          -DPYTHON_LIBRARY_DIR="/usr/local/lib/python3.10/dist-packages" \
		  -DPYTHON_EXECUTABLE="/usr/bin/python3" \
		  -DCMAKE_PREFIX_PATH="${HPX_DIR}/cmake/HPX" \
		  -DMKL_DIR="${MKL_DIR}/cmake/mkl" ${MKL_CONFIG} \
	          -DCMAKE_CXX_FLAGS_RELEASE="-march=native -O3" # Configure the project

make clean
make -j4 all           # Build the project

################################################################################
# Run benchmark script
################################################################################

cd ../test
nohup python execute.py > error_py.out 2>&1 &
#python3 test_py.py
