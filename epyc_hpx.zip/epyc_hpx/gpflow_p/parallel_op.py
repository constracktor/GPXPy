import time
import os
import logging

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import tensorflow as tf
import gpflow
import numpy as np

from config import get_config
from gpflow_logger import setup_logging
from utils import load_data
from sklearn.metrics.pairwise import rbf_kernel

logger = logging.getLogger()
log_filename = "./operations_para.log"


def gpflow_run(config, output_file, size_train, l, cores):
    """
    Run the GPflow regression pipeline.

    Args:
        config (dict): Configuration parameters for the pipeline.
        output_csv_obj (csv.writer): CSV writer object for writing output data.
        size_train (int): Size of the training dataset.
        l (int): Loop index.

    Returns:
        None
    """   
    X_train, Y_train, X_test = load_data(
        train_in_path=config["train_in_file"],
        train_out_path=config["train_out_file"],
        test_in_path=config["test_in_file"],
        size_train=size_train,
        size_test=config["N_TEST"],
        n_regressors=config["N_REG"],
    )

    
    K = rbf_kernel(X_train, gamma=1./(2*(1.**2))) + (0.1)*np.eye(X_train.shape[0])
    cross_K = rbf_kernel(X_train, X_test, gamma=1./(2*(1.**2)))
    # Cast the matrix to a TensorFlow tensor
    tensor = tf.convert_to_tensor(K, dtype=tf.float64)
    cross_tensor = tf.convert_to_tensor(cross_K, dtype=tf.float64)
    
    # Compute the Cholesky decomposition
    #total = time.time()

    cholesky_decomp = tf.linalg.cholesky(tensor)
    #Y = tf.linalg.matmul(tensor, cross_tensor)
    total = time.time()

    A = tf.linalg.triangular_solve(cholesky_decomp, tensor, lower=True)
    total = time.time() - total
    
    logger.info(f"{cores},{size_train},{total},{l}")

def execute():
    setup_logging(log_filename, True, logger)
    config = get_config()

    file_path = "./results.txt"
    file_exists = os.path.isfile(file_path)

    with open(file_path, "a") as output_file:
        if not file_exists or os.stat(file_path).st_size == 0:
            logger.info("Cores,N_train,Total_time,N_loop")

        start = config["START"]
        end = config["END"]
        step = config["STEP"]
        gpflow.config.set_default_float(np.float64)

        for core in range(7, config["N_CORES"]):
            num_threads = 2**core
            tf.config.threading.set_intra_op_parallelism_threads(num_threads)
            tf.config.threading.set_inter_op_parallelism_threads(num_threads)
            for data in range(start, end+step, step):
                for l in range(config["LOOP"]):
                    gpflow_run(config, output_file, data, l, 2**core)


if __name__ == "__main__":
    execute()


