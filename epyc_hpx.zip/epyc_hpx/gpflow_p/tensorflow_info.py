import os
import tensorflow as tf

# Print OpenMP related environment variables
print("OMP_NUM_THREADS:", os.getenv("OMP_NUM_THREADS"))
print("KMP_BLOCKTIME:", os.getenv("KMP_BLOCKTIME"))
print("KMP_AFFINITY:", os.getenv("KMP_AFFINITY"))


# Print TensorFlow compile flags
print("TensorFlow compile flags:")
print(tf.sysconfig.get_compile_flags())

# Print TensorFlow link flags
print("\nTensorFlow link flags:")
print(tf.sysconfig.get_link_flags())

# Print TensorFlow version
print("\nTensorFlow version:")
print(tf.__version__)

