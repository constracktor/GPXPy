import tensorflow as tf
from tensorflow.python.client import device_lib

# List all physical devices
print("Physical devices:")
print(tf.config.experimental.list_physical_devices())

# List all available devices
def get_available_devices():
    local_device_protos = device_lib.list_local_devices()
    return [x.name for x in local_device_protos]


# TensorFlow compile flags
print("\nTensorFlow compile flags:")
print(tf.sysconfig.get_compile_flags())

# TensorFlow link flags
print("\nTensorFlow link flags:")
print(tf.sysconfig.get_link_flags())

# TensorFlow version
print("\nTensorFlow version:")
print(tf.__version__)

